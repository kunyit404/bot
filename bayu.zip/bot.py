# autocoment group
# karjok pangesty
# 5-19-2020 1:09 pm
from requests import *
from headerz import headerz
import re,os,json,html,time
# colors
lx = "\033[0m"
lr = "\033[91m"
lg = "\033[92m"
ly = "\033[93m"
lb = "\033[94m"
lc = "\033[95m"
try:
	os.mkdir("cache")
except:
	pass
def banner(user):
	os.system("clear")
	print(f"""
{lg}    ____                  {lx} ______            __    
{lg}   / __ )____ ___  ____  _{lx}/_  __/___  ____  / /____
{lg}  / __  / __ `/ / / / / / /{lx}/ / / __ \/ __ \/ / ___/
{lg} / /_/ / /_/ / /_/ / /_/ /{lx}/ / / /_/ / /_/ / (__  ) 
{lg}/_____/\__,_/\__, /\__,_/{lx}/_/  \____/\____/_/____/  
{lg}            /____/ {ly}User: {lb}{user}{lx}
{lg}{'-'*40}{lx}
""")
#def text():
#	txt = ""
#	print(f"Type {ly}!done{lx} if you're done")
#	while True:
#			i = input()
#			if i == "!done":
#				break
#			elif len(i) != 0:
#				txt += i+"\n"
#			
#			else:
#				txt += "\n"

def search_file(*format,file_name):
#	pi = input('\033[92m[*] \033[0mType file name to search:  ')
	fp =[]
	def ext(args,file):
		cont = []
		for x in args:
			if file.endswith('.'+x):
				cont.append(True)
			else:
				cont.append(False)
		return any(cont)
	if len(file_name) != 0:
		for r,d,f in os.walk("/sdcard"):
				for file in f:
					p = os.path.join(r,file)
					if ext(format,p):
						if file_name == file.split(".")[0]:
							fp.append((p,file))
	if len(fp) != 0:
			for x in range(len(fp)):
				print(f"   \033[92m{x+1}.\033[0m {fp[x][1]}")
			n = input('\033[92m[*] \033[0mSelect number, enter to pass:  ')
			if len(n) == 0:
					pass
					image = (None,None)
			else:
					image = fp[int(n)-1]
	else:
		print("\033[91m[!]\033[0m File not found. pass")
		image = (None,None)
	return image

def cookie_is_valid(cookie_map):
	print("Validating your cookie..")
	r = get("https://mbasic.facebook.com",cookies=cookie_map)
	owner = re.search(r"\"mbasic_logout_button\">.*?\((.*?)\)\<\/a\>",r.text)
	if owner:
		owner = owner.group(1)
		cookie = {"owner":owner,"cookie":cookie_map}
		json.dump(cookie,open("cache/cookie.json","w"))
		print(f"Your cookie is valid. Loged in as {lg}{owner}{lx}")
		valid = True
	else:
		if "checkpoint/block" in r.text:
			print(f"{ly}Account has checkpoint")
		else:
			print(r.text)
			print(f"{lr}Your cookie is invalid.\nPlease generate new account session cookie from your browser{lx}")
		valid = False
	return valid
def cookie():
	if "cookie.json" not in os.listdir("cache"):
		print(f"Paste your header string from HttpCanary.\nSee tutorial on {ly}https://youtu.be/KffBr2_jRjg{lx}\n")
		cookie_str = hd.header_input()
		hdr = hd.parser(cookie_str)
		cookie = {"Cookie":hd.cookie_builder(hdr["cookie"])}
		if cookie_is_valid(cookie):
			cookie = json.load(open("cache/cookie.json"))
		else:
			cookie = None
	else:
		cookie = json.load(open("cache/cookie.json"))
		if cookie_is_valid(cookie["cookie"]):
			cookie = cookie
		else:
			try:
				os.system("rm cache/*")
			except:
				pass
			cookie = None
			exit()
	return cookie
def get_group_id(kuki):
	print('Get your group list. ',end="")
	if "group_list.json" in os.listdir('cache'):
		print('Cache available.\nGet group list from cache..')
		group_list = json.load(open("cache/group_list.json"))
	else:
		print('Group list cache not found. Get group list from your account..')
		r = get('https://mbasic.facebook.com/groups/?seemore&refid=27',cookies=kuki)
		owner = re.search(r"\"mbasic_logout_button\">.*?\((.*?)\)\<\/a\>",r.text).group(1)
		#grub_id = re.findall(r'\/groups\/(\d+)',r.text)
		grub_id = re.findall(r"href.*?groups\/([a-zA-Z0-9\.]*)\/\?.*?\>(.*?)\<",r.text)
		grub_id = [i for i in grub_id[1:]]
		group_list= {"owner":owner}
		data = []
		if len(grub_id) != 0:
			grub_name = re.findall(r'\<a href\=\"\/groups\/\d+\?refid\=\d+\"\>(.*?)\<',r.text)
			for k,v in grub_id:
				data.append({"id":k,"name":html.unescape(v)})
			group_list["data"] = data
			json.dump(group_list,open("cache/group_list.json","w"))
	return group_list
def get_group_posts(id,kuki,count,delay,v):
	urls = [f"https://mbasic.facebook.com/groups/{id}"]
	n = 0
	posts = []
	while True:
		if len(posts) == count:
			break
		r = get(urls[n],cookies=kuki).text
		n += 1
		#https://mbasic.facebook.com/groups/713012688816352?view=permalink&id=1332586956858919&refid=18&_ft_=qid.6828440510759857915%3Amf_story_key.1332586956858919%3Agroup_id.713012688816352%3Atop_level_post_id.1332586956858919%3Atl_objid.1332586956858919%3Acontent_owner_id_new.100006550751228%3Aoriginal_content_id.2028718100689862%3Aoriginal_content_owner_id.100006550751228%3Asrc.22%3Aphoto_id.2028717740689898%3Astory_location.6%3Aattached_story_attachment_style.photo%3Afilter.GroupStoriesByActivityEntQuery&__tn__=%2AW-R#footer_action_list
		#post_id = re.findall(r'href\=\"(\/groups\/\d+\?view\=.*?footer\_action\_list)\"',r)
		post_id = re.findall(r'[Kk]omenta[ri]+.*?<a href=\"(.*?)\">Berita Lengkap<\/a>',r)
		if post_id:
			for i in post_id:
				if len(posts) == count:
					break
				#x = re.search(r'Komentari.*?href\=\"(\/groups\/\d+\?view\=permalink.*?\d+.*?\d+.*?\d+.*?\d+.*?\d+.*?\d+.*?\d+.*?\d+.*?\#footer\_action\_list)',str(i))
				#x = re.search(r'<a href=\"(.*?)\">Berita Lengkap<\/a>',str(i))
				#print(x)
				if i.startswith("/"):
					posts.append("https://mbasic.facebook.com"+html.unescape(i))
				else:
					posts.append(html.unescape(i))
				if v:
						print(f"\r{lg}{len(posts)}{lx} posts ID retrieved..",end="",flush=True)
						time.sleep(0.1)
		else:
			pass
		try:
			next = re.search(r'\"(\/groups\/\d+\?bacr.*?multi_permalinks.*?)\"',r)
			urls.append("https://mbasic.facebook.com"+html.unescape(next.group(1)))
		except:
			break
		time.sleep(delay)
	return posts
def comment(url,kuki,file,text):
		r = get(url,cookies=kuki).text
		data = {"view_photo":"Lampirkan Foto"}
#		data = {"post":"Komentari","comment_text":text}

		fbdtsg = re.search(r'name\=\"fb\_dtsg\" value\=\"(.*?)\"',r).group(1)
		jazoest = re.search(r'name\=\"jazoest\" value\=\"(.*?)\"',r).group(1)
		data.update({"fb_dtsg":fbdtsg,"jazoest":jazoest})
		url = re.findall(r'\"(\/a\/comment.php.*?)\"',r)[0]
		rr = post("https://mbasic.facebook.com"+html.unescape(url),data=data,cookies=kuki).text
		
		datax = {"post":"Komentari","comment_text":text}
		file = {"photo":("photo.jpg",open(file,'rb'),"image/*")}
		fbdtsgx = re.search(r'name\=\"fb\_dtsg\" value\=\"(.*?)\"',rr).group(1)
		jazoestx = re.search(r'name\=\"jazoest\" value\=\"(.*?)\"',rr).group(1)
		datax.update({"fb_dtsg":fbdtsgx,"jazoest":jazoestx})
		urlz = re.search(r'action\=\"(.*?)\"',rr).group(1)
		rrr = post(html.unescape(urlz),data=datax,files=file,cookies=kuki).text
		if "mbasic_logout_button" in rrr:
			print(" Success")
		else:
			print(" Gagal")
			
#def comment_to_each_group(kuki):
#	text = hd.header_input()
#	fname = input("Input photo name: ")
#	file = search_file("jpg","png",file_name=fname)[0]
#	if file:
#		print("Get group ID")
#		gid = get_group_id(kuki)["data"]
#		n = 1
#		print(f"{len(gid)} target groups.")
#		for i in gid:
#			print(f"[{lg}{n}.{lx}] Get 1 post from {i['name']}..")
#			n += 1
#			g_post = get_group_posts(i["id"],kuki,1,v=False)
#			print(f"Send comment.. ",end="")
#			comment(g_post[0],kuki,file,text)
#			time.sleep(10)
	
def comment_to_one_group(kuki):
	gid = get_group_id(kuki)
	n = 1
	for i in gid["data"]:
		print(f'{lg}{n}.{lx} {i["name"]}')
		n+=1
	s = int(input(f"Select group 1-{len(gid['data'])}: ")) - 1
	txtname = input("Input txt file name: ")
	txt = search_file("txt",file_name=txtname)[0]
	if txt:
		txt = open(txt,"r").read().split("%%%")
		print(f"comment count: {len(txt)}")
		count = int(input("Posts count: "))
		if len(txt) == count:	
			fname = input("Input photo name: ")
			file = search_file("jpg","png",file_name=fname)[0]
			if file:
				delay = int(input("Input delay (in second): "))
				print(f"Get posts from {gid['data'][s]['name']}..")
				posts_id = get_group_posts(gid['data'][s]['id'],kuki,count,delay=delay,v=True)
				if posts_id:
					if len(posts_id) < len(txt):
						print(f"\nOnly get {len(posts_id)} posts")
						print(f"Start autocomment with delay {delay} sec..")
						txt = txt[:len(posts_id)]
					else:
						print(f"\nStart autocomment with delay {delay} sec..")
					for i,text in zip(posts_id,txt):
						id = re.search(r"id\=(\d+)\&",i).group(1)
						print(f"ID {lg}{id}{lx}",end="")
						comment(i,kuki,file,text.strip())
						time.sleep(delay)
				else:
					print("Failed get posts")
		else:
			print("length of comment must be same with count of posts")
			
def main(kuki,user):
	banner(user)
	comment_to_one_group(kuki)
if __name__=='__main__':
	banner("karjok pangesty")
	hd = headerz()	
	kuki = cookie()
	if kuki:
		main(kuki["cookie"],kuki["owner"])
	
